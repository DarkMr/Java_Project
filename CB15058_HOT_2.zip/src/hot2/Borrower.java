/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hot2;

/**
 *
 * @author FSK
 */
public abstract class Borrower {
    protected String name;
    protected String faculty;
    protected int numOfBorrowerBooks;
    protected int daysBorrowed;
    
    public Borrower(){
        name = "";
        faculty = "";
        numOfBorrowerBooks = 0;
        daysBorrowed = 0;
    }
    
    public Borrower(String n,String f,int num,int d)
    {
        name = n;
        faculty = f;
        numOfBorrowerBooks = num;
        daysBorrowed = d;
    }
    
    public abstract double fine();
    
    public int Overdue()
    {
        return daysBorrowed;
    }
    
    public String getName()
    {
        return name;
    }
    
    public int NumBorrowedDays()
    {
        return this.numOfBorrowerBooks;
    }
    
    public String getFaculty()
    {
        return this.faculty;
    }
    
    public int getDaysBorrowed()
    {
        return this.daysBorrowed;
    }
    
    @Override
    public String toString()
    {
        return("Name : " + this.getName());
    }
    
}
