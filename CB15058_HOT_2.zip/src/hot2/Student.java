
package hot2;


public class Student extends Borrower{
    private int StudentID;
    
    public Student()
    {
        this.StudentID = 0;
    }
    
    public Student(String n,String f,int num,int d,int id)
    {
        super(n,f,num,d);
        this.StudentID = id;
    }
    
    @Override
    public int Overdue()
    {
        return super.Overdue();
    }
    
    @Override
    public double fine()
    {
        double totalFine = 0;
        return totalFine;
    }
    
    public int getStudentID()
    {
        return StudentID;
    }
    
    public String toString()
    {
        return (super.toString());
    }
}
