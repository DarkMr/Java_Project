
package hot2;


public class Staff extends Borrower{
    private int StaffID;
    
    public Staff()
    {
        StaffID = 0;
    }
    
    public Staff(String n,String f,int num,int d,int id)
    {
        super(n,f,num,d);
        this.StaffID = id;
    }
    
    @Override
    public int Overdue()
    {
        int result = super.Overdue() - 30;;
        if (result <= 0)
        {
            result = 0;
        }
        return result;
    }
    
    @Override
    public double fine()
    {
        int fine = this.Overdue();
        double totalFine = 0;
        
        if (fine > 0 && fine <= 5)
        {
            totalFine = super.numOfBorrowerBooks * fine * 0.20;
        }
        if (fine > 5 && fine <= 8)
        {
            totalFine = super.numOfBorrowerBooks * fine * 0.30;
        }
        if (fine > 8)
        {
            totalFine = super.numOfBorrowerBooks * fine * 0.40;
        }
        return totalFine;
    }
    
    public int getStaffID()
    {
        return StaffID;
    }
    
    @Override
    public String toString()
    {
        return(super.toString()+ "\n" + "Overdue :" +this.Overdue() + "\n" + "Fine :RM" + this.fine());
    }
}
