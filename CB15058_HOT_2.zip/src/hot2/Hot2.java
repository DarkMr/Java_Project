/*
 * Name : MOHAMMAD SYAFI AZIM BIN MOHD RAZAM
 * Student ID : CB15058
 * Lab Group : 02A
 * Task : HOT #2
 */
package hot2;

import java.util.Scanner;

/**
 *
 * @author FSK
 */
public class Hot2 {

   
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Staff staff;
        Student std;
        System.out.println("EXAMPLE STAFF");
        System.out.println("Name :"); //Ask staff name
        String n = input.next();
        System.out.println("Staff ID :");//Ask staff ID
        int id = input.nextInt();
        System.out.println("Faculty : ");//Ask staff Faculty
        String f = input.next();
        System.out.println("Num. of Books Borrows :");//Ask staff number of book borrow
        int num = input.nextInt();
        System.out.println("Days Borrowed :");//Ask staff day book borrow
        int d = input.nextInt();
        
        System.out.println(staff = new Staff(n,f,num,d,id));
        
        System.out.println("EXAMPLE POSTGRAD STUDENT");
        System.out.println("Name :");//Ask student name
        String na = input.next();
        System.out.println("Student ID :");//Ask staff ID
        int stdid = input.nextInt();
        System.out.println("Status : ");//Ask student Status
        String s = input.next();
        System.out.println("Faculty : ");//Ask student Faculty
        String fa = input.next();
        System.out.println("Num. of Books Borrows :");//Ask student number of book borrow
        int number = input.nextInt();
        System.out.println("Days Borrowed :");//Ask student day book borrow
        int day = input.nextInt();
        
        System.out.println(std = new Postgrad(na,fa,number,day,stdid,s));
        
         System.out.println("EXAMPLE UNDERGRAD STUDENT");
        System.out.println("Name :");
        String name = input.next();
        System.out.println("Student ID :");
        int stdid2 = input.nextInt();
        System.out.println("Status : ");
        String st = input.next();
        System.out.println("Faculty : ");
        String fac = input.next();
        System.out.println("Num. of Books Borrows :");
        int numberOfBorrower = input.nextInt();
        System.out.println("Days Borrowed :");
        int days = input.nextInt();
        
        System.out.println(std = new Undergrad(name,fac,numberOfBorrower,days,stdid2,st));
    }
    
}
