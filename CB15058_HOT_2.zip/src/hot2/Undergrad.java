/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hot2;

import javafx.scene.input.DataFormat;

/**
 *
 * @author FSK
 */
public class Undergrad extends Student{
    private String status;
    public Undergrad()
    {
        this.status ="";
    }
    
    public Undergrad(String n,String f,int num,int d,int id,String s)
    {
        super(n,f,num,d,id);
        this.status =s;
    }
    
    @Override
    public int Overdue()
    {
        int result = super.Overdue() - 10;
        if (result <= 0)
        {
            result = 0;
        }
        return result;
    }
    
    @Override
    public double fine()
    {
        int fine = this.Overdue();
        double totalFine = 0;
        
        if (fine > 0 && fine <= 5)
        {
            totalFine = super.numOfBorrowerBooks * fine * 0.20;
        }
        if (fine > 5 && fine <= 8)
        {
            totalFine = super.numOfBorrowerBooks * fine * 0.30;
        }
        if (fine > 8)
        {
            totalFine = super.numOfBorrowerBooks * fine * 0.40;
        }
        return  totalFine;
    }
    
    public String getStatus()
    {
        return this.status;
    }
    
     public String toString()
    {
        return (super.toString() + "\n" + "Status :" +this.status + "\n" + "Overdue : " + this.Overdue() + "\nFine :RM" + this.fine() );
    }
}
